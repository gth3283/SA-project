using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

public class Inventory : MonoBehaviour
{
    public List<Item> items;

    [SerializeField]
    private Transform slotParent;
    [SerializeField]
    private Slot[] slots;

#if UNITY_EDITOR
    private void OnValidate()
    {
        slots = slotParent.GetComponentsInChildren<Slot>();
    }
#endif

    private void Awake()
    {
        FreshSlot();
    }

    public void FreshSlot() //������ ���� ����
    {
        int i = 0;
        for(; i < items.Count && i < slots.Length; i++)
            slots[i].item = items[i];
        for(; i < slots.Length; i++)
            slots[i].item = null;
    }

    public void AddItem(Item _item)
    {
        if (items.Count < slots.Length)
        {
            items.Add(_item);
            Debug.Log(_item.itemName + " added to inventory.");  // �������� �߰��� �� �α� ���
            FreshSlot();
        }
    }

    public void UseItem(int itemID)
    {
        if(items.Count > 0)
        {
            int findItem = items.FindIndex(item => item.itemID.Equals(itemID)); //��ġ�ϴ� ���� ã���� �ε��� ����, ������ -1
            if (findItem != -1)
            {
                items.RemoveAt(findItem);
                FreshSlot();
                return;
            }
        }
    }

    public bool HasItem(int itemID)
    {
        return items.Any(item => item.itemID == itemID);  
    }
}
