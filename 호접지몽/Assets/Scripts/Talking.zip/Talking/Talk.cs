using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class Talk
{
    [TextArea(1,5)]
    public string[] sentences;

    public string[] name;
    //public Sprite[] sprites;
   // public Sprite[] windows;
}
